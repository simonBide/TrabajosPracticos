#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int main()
{
    float numberOne = 0;
    float numberTwo = 0;
    int flag = 1;
    int userOpcion;
    float resultSum;
    float resultSubstracts;
    float resultDivision;
    float resultMultiplication;
    int resultFactorialOne;
    int resultFactorialTwo;
    int flagOperations = 0;
    int flagNumberOne = 0;
    int flagNumbreTwo = 0;

    printf(" \n Calculadora de Simon Bide.    TP 1.      1 E \n\n\n");
    do
    {
        printf("\n \n");
        printf("1. Ingresar 1er operando\t \t(A=%.2f)\n",numberOne);
        printf("2. Ingresar 2do operando\t \t(B=%.2f)\n",numberTwo);
        printf("3. Calcular todas las operaciones\n");
        printf("4. Informar resultados\n");
        printf("5. Salir\n");
        scanf("%d",&userOpcion);

        switch(userOpcion)
        {
        case 1:
            flagNumberOne = 1;
            printf("    Ingresar 1er operando: ");
            scanf("%f",&numberOne);
            break;
        case 2:
            flagNumbreTwo = 1;
            printf("    Ingresar 2do operando: ");
            scanf("%f",&numberTwo);
            break;
        case 3:
            if ( flagNumberOne == 1 && flagNumbreTwo == 1 )
            {
                flagOperations = 1;
                printf("    Operaciones calculadas.\n");
                resultSum = functionSum(numberOne,numberTwo);
                resultSubstracts = functionSubstraction(numberOne,numberTwo);
                resultDivision = functionDivision(numberOne,numberTwo);
                resultMultiplication = functionMultiplication(numberOne,numberTwo);
                resultFactorialOne = functionFactorial(numberOne);
                resultFactorialTwo = functionFactorial(numberTwo);
            }
            else
            {
                printf("Primero debe ingresar los valores de ambos numeros. \n");
            }
            break;
        case 4:
            if ( flagOperations == 1 )
            {
                printf("El resultado de la suma es: %.2f \n",resultSum);
                printf("El resultado de la resta es: %.2f \n",resultSubstracts);
                if ( resultDivision == -1 )
                {
                    printf("No se puede dividir por 0 \n");
                }
                else
                {
                    printf("El resultado de la division es: %.2f \n",resultDivision);
                }
                printf("El resultado de la multiplicacion es: %.2f \n",resultMultiplication);

                if(resultFactorialOne == (-1))
                {
                    printf("No se puede hacer factorial de el numero %.2f \n",numberOne);
                }
                else
                {
                    printf("El resultado factorial del numero %.0f es: %d \n",numberOne,resultFactorialOne);
                }
                if(resultFactorialTwo == (-1))
                {
                    printf("No se puede hacer factorial de el numero %.2f \n",numberTwo);
                }
                else
                    printf("El resultado factorial del numero %.0f es: %d \n",numberTwo,resultFactorialTwo);
            }
            else
            {
                printf("Primero se deben realizar las operaciones. \n");
            }
            break;
        case 5:
            flag = 0;
            break;
        default:
            printf("Opcion no valida. \n");
            break;
        }
    }
    while(flag);
}

