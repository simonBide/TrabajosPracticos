#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

/** \brief Recibe dos numeros y los suma.
 * \param numeroUno es el primer valor ingresado.
 * \param numeroDos es el segundo valor que se ingresa.
 * \return Devuelve la suma de ambos numeros en un float.
 */

float functionSum(float numeroUno,float numeroDos)
{
    // float resultado = numeroDos + numeroUno;
    // return resultado;
    return (numeroUno + numeroDos);
}

/** \brief Recibe dos numeros y los resta.
 * \param numeroUno es el primer valor ingresado.
 * \param numeroDos es el segundo valor que se ingresa.
 * \return Devuelve la resta de ambos numeros en un float.
 */

float functionSubstraction (float numeroUno,float numeroDos)
{
    return (numeroUno - numeroDos);
}

/** \brief Recibe dos numeros y los multiplica.
 * \param numeroUno es el primer valor ingresado.
 * \param numeroDos es el segundo valor que se ingresa.
 * \return Devuelve el resultado de la multiplicacion de ambos numeros en un float.
 */

float functionMultiplication (float numeroUno,float numeroDos)
{
    return (numeroUno * numeroDos);
}

/** \brief Recibe dos numeros y los divide.
 * \param numeroUno es el primer valor ingresado.
 * \param numeroDos es el segundo valor que se ingresa.
 * \return Devuelve el resultado de la division de ambos numeros en un float.
 */
float functionDivision (float numeroUno,float numeroDos)
{
    if( numeroDos != 0 )
    {
        return (numeroUno / numeroDos);
    }
    else
    {
        return -1;
    }
}

/** \brief Recibe un numero y calcula su factorial.
 * \param numeroUno es el primer valor ingresado.
 * \param numeroDos es el segundo valor que se ingresa.
 * \return Devuelve el resultado factorial del numero en un int.
 */
int functionFactorial ( float numeroFloat )
{
    int resultado =1;
    int  numero = (int)numeroFloat;
    int i;

    while(numero != numeroFloat)
    {
        return -1;
    }

    for(i = 1; i <= numero ; i++)
    {
        resultado = resultado * i;
    }
    return resultado;
}
