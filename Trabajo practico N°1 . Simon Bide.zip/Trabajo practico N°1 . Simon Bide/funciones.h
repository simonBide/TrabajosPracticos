#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

float functionSum(float,float);
float functionSubstraction (float,float);
float functionMultiplication (float,float);
float functionDivision (float,float);
int functionFactorial (float);


#endif // FUNCIONES_H_INCLUDED
